
// export const CENTER = {
//   NAME: "أ/محمد البحيري",
//   PHONE: "01041262030",
//   ADDRESS:
//     "تلا - شارع هندسة الري بجوار مكتبة الفجالة / شارع الشيخ فؤاد بجوار قهوة الشابط",
// };

/* ============ إعدادات الـ API ============ */
const TOKEN =
  process.env.WHATSAPP_TOKEN;

const PHONE_NUMBER_ID = process.env.WHATSAPP_PHONE_ID;
const API_URL = `https://graph.facebook.com/v22.0/${PHONE_NUMBER_ID}/messages`;
// const LANG_CODE = "ar_EG";

/* أسماء القوالب المعتمدة في حساب الواتساب */
export const TEMPLATE_NAMES = {
  welcome: "welcome",
  absence: "absent",
  payment: "payment",
  exam: "exam",
};

/* ============ أدوات مساعدة ============ */

/* تحويل الرقم المصري لصيغة دولية 20XXXXXXXXXX */
export function normalizePhone(phone) {
  const digits = String(phone ?? "").replace(/\D/g, "");
  if (!digits) return "";
  if (digits.startsWith("20") && digits.length >= 12) return digits;
  if (digits.startsWith("0")) return `20${digits.slice(1)}`;
  if (digits.length === 10) return `20${digits}`;
  return digits;
}

export function hasPhone(phone) {
  return normalizePhone(phone).length >= 11;
}

function today() {
  return new Date().toLocaleDateString("en-GB");
}

function text(value) {
  return { type: "text", text: String(value ?? "").trim() || "-" };
}

/* الإرسال الفعلي — أي رسالة من غير رقم بترجع skipped من غير ما تتبعت */
async function sendTemplate({ phone, name, parameters }) {
  const to = normalizePhone(phone);
  if (!hasPhone(to)) {
    return { success: false, skipped: true, error: "لا يوجد رقم للإرسال" };
  }

  const payload = {
    messaging_product: "whatsapp",
    to,
    type: "template",
    template: {
      name,
      language: { code: ar },
      components: [{ type: "body", parameters }],
    },
  };

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${TOKEN}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      const message =
        data?.error?.message || `فشل الإرسال (${response.status})`;
      return { success: false, error: message, data };
    }

    return { success: true, id: data?.messages?.[0]?.id || null, data };
  } catch (error) {
    return { success: false, error: error?.message || "تعذر الاتصال بالواتساب" };
  }
}

/* ============ 1) رسالة الترحيب — لولي الأمر عند إضافة طالب جديد ============ */
export async function sendWelcomeMsg(student = {}) {
  const phone = student.phone ?? student.Phone ?? student.parentPhone ?? student.ParentPhone;
  return sendTemplate({
    phone,
    name: TEMPLATE_NAMES.welcome,
    parameters: [
      text(student.name ?? student.Name),
      text(student.barcode),
      text(`https://boshta.benb3n.cloud/api/parent/${student.parent_token}`),
    ],
  });
}

/* ============ 2) رسالة الغياب — لما حالة الطالب تبقى غياب ============ */
export async function sendAbsentMsg(student = {}) {
  const phone = student.phone ?? student.Phone ?? student.parentPhone ?? student.ParentPhone;
  return sendTemplate({
    phone,
    name: TEMPLATE_NAMES.absence,
    parameters: [
      text(student.name ?? student.Name),
      text(student.barcode),
      text(today()),
      text(`https://boshta.benb3n.cloud/api/parent/${student.parent_token}`),
    ],
  });
}

/* ============ 3) رسالة الدفع — لما الطالب يدفع ============ */
export async function sendPaymentMsg(student = {}) {
  const phone = student.phone ?? student.Phone ?? student.parentPhone ?? student.ParentPhone;
  return sendTemplate({
    phone,
    name: TEMPLATE_NAMES.payment,
    parameters: [
      text(student.name ?? student.Name),
      text(student.month ?? student.Month),
      text(student.year ?? student.Year),
      text(student.amount ?? student.Amount),
    ],
  });
}

/* ============ 4) رسالة الاختبار — بعد حفظ رصد الدرجات ============ */
export async function sendExamMsg(student = {}) {
  const phone = student.phone ?? student.Phone ?? student.parentPhone ?? student.ParentPhone;
  return sendTemplate({
    phone,
    name: TEMPLATE_NAMES.exam,
    parameters: [
      text(student.name ?? student.Name),
      text(student.score ?? student.Score),
      text(student.fullMark ?? student.max ?? student.MaxScore),
      text(student.date ?? today()),
      text(student.day),
      text(student.barcode),
    ],
  });
}

/* ============ موزّع حسب نوع الرسالة ============ */
export async function sendByType(type, payload = {}) {
  switch (type) {
    case "welcome":
      return sendWelcomeMsg(payload);
    case "absence":
      return sendAbsentMsg(payload);
    case "payment":
      return sendPaymentMsg(payload);
    case "exam":
      return sendExamMsg(payload);
    default:
      return { success: false, error: `نوع رسالة غير معروف: ${type}` };
  }
}

export default {
//   CENTER,
  sendWelcomeMsg,
  sendAbsentMsg,
  sendPaymentMsg,
  sendExamMsg,
  sendByType,
  normalizePhone,
  hasPhone,
};
